package com.example.android_database;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    SQLiteDatabase mydatabse;
    static  String CREATE_STUDENT_TABLE="";
    final  static  String STUDENT_TABLE="tblcar";
    EditText txtname,txtmodel,txtcolor,txtprice;
    Button btnadd,btnnext;

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtname=findViewById(R.id.txtcarname);
        txtmodel=findViewById(R.id.txtcarmodel);
        txtcolor=findViewById(R.id.txtcarcolor);
        txtprice=findViewById(R.id.txtcarprice);

        btnadd=findViewById(R.id.btnsave);
        btnnext=findViewById(R.id.btnnext);


        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name=txtname.getText().toString();
                String model=txtmodel.getText().toString();
                String color=txtcolor.getText().toString();
                String price=txtprice.getText().toString();

                insertdata(name,model,color,price);





            }
        });

        btnnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             Intent intt=new Intent(MainActivity.this,secondpage.class);
             startActivity(intt);
            }
        });

        // Create Databse SQLite

        mydatabse=openOrCreateDatabase("car.db",SQLiteDatabase.CREATE_IF_NECESSARY,null);


        //create Table as your requirment....
        try {
            CREATE_STUDENT_TABLE="CREATE TABLE IF NOT EXISTS tblcar("+" Id INTEGER PRIMARY KEY AUTOINCREMENT ,"+" Carname TEXT, "+" Carmodel TEXT ,"+" Carcolor  TEXT ,"+"  Carprice TEXT "+")";
            mydatabse.execSQL(CREATE_STUDENT_TABLE);
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }

    }
   private  void insertdata( String cname,String cmodel, String cColor,String cprice){

       ContentValues values=new ContentValues();
       values.put("carname",cname);
       values.put("carmodel",cmodel);
       values.put("carcolor",cColor);
       values.put("carprice",cprice);

       mydatabse.insert(STUDENT_TABLE,null,values);
       Toast.makeText(this, "Data Add Successfully.....", Toast.LENGTH_SHORT).show();

       txtname.setText("");
       txtmodel.setText("");
       txtcolor.setText("");
       txtprice.setText("");
    }
}
