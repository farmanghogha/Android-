package com.example.android_database;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    SQLiteDatabase mydatabse;
    static  String CREATE_STUDENT_TABLE="";
    final  static  String STUDENT_TABLE="tblcar";
    EditText txtname,txtmodel,txtcolor,txtprice;
    Button btnsave,btnshow;
    String Data[];

    ArrayList data_name,data_model,data_color,data_price;

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtname=findViewById(R.id.txtcarname);
        txtmodel=findViewById(R.id.txtcarmodel);
        txtcolor=findViewById(R.id.txtcarcolor);
        txtprice=findViewById(R.id.txtcarprice);

        btnsave=findViewById(R.id.btnsave);
        btnshow=findViewById(R.id.btnnext);

        data_name=new ArrayList();
        data_model=new ArrayList();
        data_color=new ArrayList();
        data_price=new ArrayList();



        btnsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name=txtname.getText().toString();
                String model=txtmodel.getText().toString();
                String color=txtcolor.getText().toString();
                String price=txtprice.getText().toString();

                insertdata(name,model,color,price);





            }
        });

        btnshow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

             showdata();
             Intent intt=new Intent(MainActivity.this,secondpage.class);
             intt.putExtra("car",Data);
             startActivity(intt);
            }
        });

        // Create Databse SQLite

        mydatabse=openOrCreateDatabase("car.db",SQLiteDatabase.CREATE_IF_NECESSARY,null);


        //create Table as your requirment....
        try {
            CREATE_STUDENT_TABLE="CREATE TABLE IF NOT EXISTS tblcar("+" Id INTEGER PRIMARY KEY AUTOINCREMENT ,"+" Carname TEXT, "+" Carmodel TEXT ,"+" Carcolor  TEXT ,"+"  Carprice TEXT "+")";
            mydatabse.execSQL(CREATE_STUDENT_TABLE);
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }

    }
   private  void insertdata( String cname,String cmodel, String cColor,String cprice){

       ContentValues values=new ContentValues();
       values.put("carname",cname);
       values.put("carmodel",cmodel);
       values.put("carcolor",cColor);
       values.put("carprice",cprice);

       mydatabse.insert(STUDENT_TABLE,null,values);
       Toast.makeText(this, "Data Add Successfully.....", Toast.LENGTH_SHORT).show();

       txtname.setText("");
       txtmodel.setText("");
       txtcolor.setText("");
       txtprice.setText("");
    }

    private  void showdata(){


        Cursor resultSet = mydatabse.query(STUDENT_TABLE,null,null,null,null,null,null);
        Data=new String[resultSet.getCount()];
        resultSet.moveToFirst();

        int i=0;
        while(resultSet.isAfterLast()==false){
            String str=resultSet.getString(0)+" "+
                       resultSet.getString(1)+" "+
                       resultSet.getString(2)+" "+
                       resultSet.getString(3)+" "+
                       resultSet.getString(4);
            Data[i++]=str;
            resultSet.moveToNext();
        }



    }
}
