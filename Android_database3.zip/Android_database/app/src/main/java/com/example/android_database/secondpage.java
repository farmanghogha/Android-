package com.example.android_database;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;

public class secondpage extends AppCompatActivity {
   ListView l;
   String data[];
   ArrayAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondpage);
        l=findViewById(R.id.listview);

        data=getIntent().getStringArrayExtra("car");

        adapter=new ArrayAdapter(this,R.layout.support_simple_spinner_dropdown_item,data);
        l.setAdapter(adapter);




    }
}

